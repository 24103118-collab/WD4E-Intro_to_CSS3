CSS Week 1 HW1 - Completed

Files:
- index.html
- neighborhood.html
- parks.html
- css/style.css

The three HTML pages use one shared stylesheet.

The stylesheet includes the required changes for:
body, header, nav, main, footer, li, h1, and p.

Note:
The original image files are referenced from the course repository's public raw GitHub URLs so the pages can display the supplied images online without duplicating them in this ZIP.
